#include "SPHKernels.h"

using namespace PBD;

float CubicKernel::m_radius;
float CubicKernel::m_k;
float CubicKernel::m_l;
float CubicKernel::m_W_zero;
